./src.o $@
